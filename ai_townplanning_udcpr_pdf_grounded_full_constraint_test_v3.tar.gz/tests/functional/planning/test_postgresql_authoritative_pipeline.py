from __future__ import annotations

from townplanning.infrastructure.database.session import SessionLocal
from townplanning.modules.planning.domain.planning_facts import PlanningFacts
from townplanning.modules.regulations.extraction.postgresql_authoritative_table_resolver import (
    PostgreSQLAuthoritativeTableResolver,
    SelectedTable,
)


SQFT_FLAT_AREA_FOR_TEST = 750.0


def build_test_facts() -> PlanningFacts:
    # TEST INPUT ONLY. 750 sq ft is the sample flat/carpet-area input requested
    # for the parking/balcony tests. It is not a regulatory value.
    return PlanningFacts(
        project_type="Residential Apartment",
        development_type="New Construction",
        city="Pune",
        district="Pune",
        state="Maharashtra",
        planning_authority="Pune Municipal Corporation",
        municipality="Pune Municipal Corporation",
        municipal_corporation="Pune Municipal Corporation",
        competent_authority="Pune Municipal Corporation",
        zone="Residential R-1",
        zone_type="Residential",
        land_use_zone="R-1",
        land_use_classification="Residential",
        congested_area=False,
        group_housing=False,
        building_type="Residential Apartment",
        building_use="residential",
        occupancy_type="residential",
        road_width=12.0,
        # PlanningFacts stores numeric carpet area; convert the explicit test
        # assumption from 750 sq ft to square metres for UDCPR table matching.
        tenement_carpet_areas={
            "2BHK": SQFT_FLAT_AREA_FOR_TEST * 0.09290304,
            "3BHK": SQFT_FLAT_AREA_FOR_TEST * 0.09290304,
        },
        values={
            "test_flat_area_sqft": SQFT_FLAT_AREA_FOR_TEST,
        },
        basic_fsi=None,
        premium_fsi=None,
        tdr_fsi=None,
        incentive_fsi=None,
        maximum_fsi=None,
        permissible_fsi=None,
        car_parking_required=None,
        two_wheeler_parking_required=None,
        visitor_parking_required=None,
        front_setback=None,
        rear_setback=None,
        maximum_height_m=None,
    )


def source(number: str, text: str):
    return type(
        "Source",
        (),
        {
            "source_id": f"test-chroma-{number}",
            "metadata": {"regulation_number": number},
            "text": text,
        },
    )()


def values_by_field(result):
    return {item["field"]: item["value"] for item in result.constraints}


def test_outputs_are_not_preloaded():
    facts = build_test_facts()
    assert facts.basic_fsi is None
    assert facts.maximum_fsi is None
    assert facts.car_parking_required is None
    assert facts.two_wheeler_parking_required is None


def test_selected_table_is_explicit():
    selection = SelectedTable(
        regulation_number="6.3",
        table_number="6-G",
        table_title="Permissible FSI",
    )
    assert selection.regulation_number == "6.3"
    assert selection.table_number == "6-G"


def test_udcpr_table_constraints_are_read_from_postgresql():
    """
    PDF-grounded functional test.

    The Chroma objects below represent only the completed regulation/table
    selection. They contain no regulatory numeric values. All asserted values
    must be obtained from PostgreSQL tables.

    Covered UDCPR tables:
      * 6-D: residential setbacks/margins
      * 6-G: permissible FSI
      * 8-B: parking by tenement size
      * 8-C: authority parking factor
    """
    facts = build_test_facts()
    session = SessionLocal()
    try:
        resolver = PostgreSQLAuthoritativeTableResolver(session)
        sources = [
            source(
                "6.2.1",
                "6.2.1 Residential Buildings\nTable No.6-D\nMinimum setback from road side\nMinimum side margins\nMinimum rear margins",
            ),
            source(
                "6.3",
                "6.3 PERMISSIBLE FSI\nTable 6-G\nRoad width in meters\nBasic FSI\nFSI on payment of premium\nMaximum permissible TDR loading\nMaximum building potential on plot including in-situ FSI",
            ),
            source(
                "8.2.1",
                "8.2.1 Off-street parking requirement\nTable No.8-B\nOccupancy\nSize of tenement\nParking Spaces Required\nCar\nScooter\nIn addition 5% visitor parking",
            ),
            source(
                "8.2.2",
                "8.2.2 Off street parking requirement for various Planning Authorities / Areas\nTable No.8-C\nAuthority / Area\nMultiplying Factor",
            ),
        ]

        requested = [
            "front_setback",
            "rear_setback",
            "side_setback_left",
            "side_setback_right",
            "basic_fsi",
            "premium_fsi",
            "tdr_fsi",
            "maximum_fsi",
            "car_parking_required",
            "two_wheeler_parking_required",
            "visitor_parking_required",
        ]

        result = resolver.resolve(
            facts=facts,
            selected_regulations=["6.2.1", "6.3", "8.2.1", "8.2.2"],
            chroma_sources=sources,
            requested_fields=requested,
        )

        assert result.status in {"RESOLVED", "PARTIAL"}, (
            result.status, result.errors, result.warnings, result.missing_inputs,
            result.selections,
        )

        values = values_by_field(result)

        # Exact values from UDCPR Table 6-D for a 12 m road are expected to be
        # returned by PostgreSQL, not embedded in production code.
        assert values["front_setback"] == 3.0
        assert values["rear_setback"] == 1.5
        assert values["side_setback_left"] == 1.5
        assert values["side_setback_right"] == 1.5

        # Exact values from UDCPR Table 6-G for 12 m <= road < 15 m.
        assert values["basic_fsi"] == 1.10
        assert values["premium_fsi"] == 0.50
        assert values["tdr_fsi"] == 0.65
        assert values["maximum_fsi"] == 2.25

        # FSI maximum is only adopted as the TEST design target after it has
        # been read authoritatively from PostgreSQL.
        facts.maximum_fsi = values["maximum_fsi"]
        facts.requested_fsi = facts.maximum_fsi
        assert facts.requested_fsi == 2.25

        # The test input remains 750 sq ft per flat. Parking values are not
        # hardcoded here; the resolver must derive them from Tables 8-B/8-C.
        assert SQFT_FLAT_AREA_FOR_TEST == 750.0
        assert values["car_parking_required"] == 1
        assert values["two_wheeler_parking_required"] == 2
        assert values["visitor_parking_required"] == 0.05
    finally:
        session.close()


def test_no_ai_boundary():
    resolver = PostgreSQLAuthoritativeTableResolver
    assert "openai" not in resolver.__module__.lower()
    assert "ollama" not in resolver.__module__.lower()
