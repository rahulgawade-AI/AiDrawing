from townplanning.modules.planning.fact_context import PlanningFactContext
from townplanning.modules.planning.services.planning_service import PlanningService


context = PlanningFactContext(
    # --------------------------------------------------
    # SITE
    # --------------------------------------------------
    plot_area=745.6,
    plot_number="78/5",

    # --------------------------------------------------
    # ROAD
    # --------------------------------------------------
    road_width=18.0,
    road_widths=[18.0],
    road_frontage_count=1,
    road_locations=["south"],

    # --------------------------------------------------
    # BUILDING
    # --------------------------------------------------
    building_type="Residential",
    building_use="residential",

    # --------------------------------------------------
    # TEST FACT ONLY
    # Required by the current Basic FSI rule
    # --------------------------------------------------
    zone_type="Residential",

    # --------------------------------------------------
    # OBJECTIVE
    # --------------------------------------------------
    maximize_fsi=True,
)


# ------------------------------------------------------
# NORMALIZE / CONVERT FACTS
# ------------------------------------------------------
facts = context.to_planning_facts()


print("=" * 80)
print("NORMALIZED PLANNING FACTS")
print("=" * 80)

print("building_type :", facts.building_type)
print("building_use  :", facts.building_use)
print("zone_type     :", facts.zone_type)
print("plot_area     :", facts.plot_area)
print("road_width    :", facts.road_width)
print("road_locations:", facts.road_locations)


# ------------------------------------------------------
# RUN PLANNING ENGINE
# ------------------------------------------------------
service = PlanningService()

constraints = service.evaluate(facts)


print()
print("=" * 80)
print("FINAL PLANNING RESULT")
print("=" * 80)

print("basic_fsi                =", constraints.basic_fsi)
print("premium_fsi              =", constraints.premium_fsi)
print("tdr_fsi                  =", constraints.tdr_fsi)
print("incentive_fsi            =", constraints.incentive_fsi)
print("maximum_fsi              =", constraints.maximum_fsi)
print("total_fsi                =", constraints.total_fsi)
print("maximum_built_up_area    =", constraints.maximum_built_up_area)
print("maximum_ground_coverage  =", constraints.maximum_ground_coverage)

print("front_setback            =", constraints.front_setback)
print("rear_setback             =", constraints.rear_setback)
print("side_setback_left        =", constraints.side_setback_left)
print("side_setback_right       =", constraints.side_setback_right)

print("maximum_height_m         =", constraints.maximum_height_m)
print("maximum_storeys          =", constraints.maximum_storeys)

print("car_parking_required     =", constraints.car_parking_required)
print("two_wheeler_parking_req  =", constraints.two_wheeler_parking_required)
print("visitor_parking_required =", constraints.visitor_parking_required)
print("parking_area_required    =", constraints.parking_area_required)